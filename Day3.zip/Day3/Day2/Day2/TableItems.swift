//
//  TableItems.swift
//  Day2
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    static var Titles : [String] = ["Audio", "Video", "Web View", "Calender", "Location", "Contacts"]
    static var subtitles : [String] = ["Hear it clear", "Watch it better", "World is yours", "Time is not yours", "Be everywhere", "Stay Commented"]
    static var images : [String] = ["Audio", "Video", "Web View", "Calender", "Location", "Contacts"]
}
